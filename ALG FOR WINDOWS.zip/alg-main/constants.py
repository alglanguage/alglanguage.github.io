KEYWORDS = ["function","class","if","for","else","True","False","print","bool","int","str"]
BUILT_IN_FUNCTIONS = ["print"]
DATATYPE = ["bool","int","str"]
