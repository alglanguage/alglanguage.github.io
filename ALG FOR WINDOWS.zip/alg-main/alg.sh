py main.py $1
